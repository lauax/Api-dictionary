## Available Scripts

In the project directory, you can run:
### `cd my-app`
cd my-app: This command changes the directory to my-app. This is to navigate into the project folder before running other commands.

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.

### `npm test`

Runs tests that ensure that the code mainly works as it should.

